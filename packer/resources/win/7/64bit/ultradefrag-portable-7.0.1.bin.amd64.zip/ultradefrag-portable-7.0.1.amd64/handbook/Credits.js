var Credits =
[
    [ "GNU Library General Public License", "LGPL_2_0.html", null ],
    [ "GNU Lesser General Public License", "LGPL_3_0.html", null ],
    [ "GNU Free Documentation License", "FDL.html", null ],
    [ "GNU General Public License", "GPL.html", null ]
];